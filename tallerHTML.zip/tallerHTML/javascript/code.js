var color = ["#00AA4D", "black", "#E6E7E9", "white"];
document.getElementById("cambio").addEventListener(
            "mouseover", function () {
                        
  
            document.getElementById("cambio").style.background 
                = color[2];
            
            document.getElementById("cambio").style.border="thin ridge black";
            }



)

document.getElementById("cambio").addEventListener(
    "mouseleave", function () {
                

    document.getElementById("cambio").style.background 
        = color[3];
    document.getElementById("cambio").style.border="thin solid white";
    
    
    }
)
try{

    document.getElementById("seccionExperiencia_").addEventListener(
        "mouseover", function () {
                    
    
        document.getElementById("seccionExperiencia_").style.background 
            = color[2];
        
        document.getElementById("seccionExperiencia_").style.border="thin ridge black";
        }
    
    
    
    )
    
    document.getElementById("seccionExperiencia_").addEventListener(
    "mouseleave", function () {
            
    
    document.getElementById("seccionExperiencia_").style.background 
    = color[3];
    document.getElementById("seccionExperiencia_").style.border="thin solid white";
    
    
    }
    )

}catch(err){}




const navbarMenu = document.querySelector(".navbar ul");
const navbarLinks= document.querySelectorAll(".navbar a");

navbarLinks.forEach(elem=>elem.addEventListener("click",navbarLinkClick));

function navbarLinkClick(event){
    smoothScroll(event);
}

function smoothScroll(event){
    event.preventDefault();
    const targetId= event.currentTarget.getAttribute("href");
    const targetPosition = document.querySelector(targetId).offsetTop;
    const startPosition=window.pageYOffset;
    const distance = targetPosition - startPosition;
    const duration= 1000;
    let start = null;

    window.requestAnimationFrame(step);

    function step(timestamp){
        if(!start) start = timestamp;
        const progress = timestamp - start;
        window.scrollTo(0,distance*(progress/duration)+startPosition);
        if(progress<duration) window.requestAnimationFrame(step);
    }


    console.log(targetId);
    
}

/////////////////////////////////7
const navpMenu = document.querySelector(".navp ul");
const navpLinks= document.querySelectorAll(".navp a");

navpLinks.forEach(elem=>elem.addEventListener("click",navpLinkClick));

function navpLinkClick(event){
    smoothScroll(event);
}

function smoothScroll(event){
    event.preventDefault();
    const targetId= event.currentTarget.getAttribute("href");
    const targetPosition = document.querySelector(targetId).offsetTop;
    const startPosition=window.pageYOffset;
    const distance = targetPosition - startPosition;
    const duration= 500;
    let start = null;

    window.requestAnimationFrame(step);

    function step(timestamp){
        if(!start) start = timestamp;
        const progress = timestamp - start;
        window.scrollTo(0,distance*(progress/duration)+startPosition);
        if(progress<duration) window.requestAnimationFrame(step);
    }


    console.log(targetId);
    
}

var coment=[
    {"nombre": "Jesus","body":"this is a coment"}
  ];

function openForm() {
    document.getElementById("myForm").style.display = "block";
  }
  function closeForm() {
    document.getElementById("myForm").style.display = "none";
  }

  const maxPermitted = 300;
  // La varible de control
  let validArea = false;
  
  const area = document.querySelector('#area');
  const submit = document.querySelector('#sbmit');
  const error = document.querySelector('#area-error');
  const namea = document.querySelector('#nombre');
  
  function verifica(){
    const {value}= namea;
    if(validArea==false && namea.length!=0){
        alert("Verifica los Campos");
    }
    else{
        alert("Ok Enviado");
        var addObj={
            "nombre": document.querySelector('#remit').value,//val()
            "body":  document.querySelector('#area').value
          };
          console.log(addObj);
          coment.push(addObj);
          console.log(coment.length);
          render(addObj);
    }
  }
  
  try{
    area.addEventListener("input", () => {
        const { value } = area;
        
        value.length >= maxPermitted
            ? handleInvalid()
            : handleValid();
    });
  }catch(err){}
  
  const handleInvalid = () => {
      validArea = false;
      error.style.display = "block";
      submit.disabled=true;
      submit.style.background = "black";
  }
  
  const handleValid = () => {
      validArea = true;
      error.style.display = "none";
      submit.disabled=false;
      submit.style.background = "#00AA4D";
  }
//////////////////////////////////CHAT


  function render(data){
    var html = "<div class='comentBox'></div><div class='rightPanel'><span>@"+data.nombre+"---->"+data.body+"</span></div></div>"
    document.getElementById("container").innerHTML+= html;
  }


  document.addEventListener("DOMContentLoaded", function() {
      for(var i=0; i<coment.length;i++){
        console.log(coment.length);
        try{
            render(coment[i]);  
        }catch(err){}
      }
  });


